<?php

namespace ZadanieTest\Porady\Block\Adminhtml\Product\Edit\Tab;

use Magento\Backend\Block\Template;

class Advice extends Template
{
    public function getAdviceTitle()
    {
        $product = $this->_coreRegistry->registry('current_product');
        return $product->getData('Porady_advice_title');
    }
}
?>