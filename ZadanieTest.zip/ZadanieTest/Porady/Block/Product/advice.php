?php

namespace ZadanieTest\Porady\Block\Product;

use Magento\Framework\View\Element\Template;
use ZadanieTest\Porady\Model\ApiClient;

class Advice extends Template
{
    private $apiClient;

    public function __construct(
        Template\Context $context,
        ApiClient $apiClient,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->apiClient = $apiClient;
    }

    public function isAdviceEnabled()
    {
        return $this->_scopeConfig->isSetFlag('Porady/general/enabled', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getAdviceTitle()
    {
        return $this->_scopeConfig->getValue('Porady/general/title', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getAdviceContent()
    {
        $productName = $this->_coreRegistry->registry('current_product')->getName();
        $advice = $this->apiClient->getAdviceByProductName($productName);

        if (!$advice) {
            $advice = $this->apiClient->getAdviceById(2);
        }

        return $advice;
    }
}
?>