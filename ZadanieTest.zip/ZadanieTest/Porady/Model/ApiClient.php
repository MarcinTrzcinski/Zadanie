<?php
  
namespace ZadanieTest\Porady\Model;
  
class ApiClient
{
    public function getAdviceByProductName($productName)
    {
        $apiUrl = 'https://api.adviceslip.com/advice/search/' . urlencode($productName);
    }
  
    public function getAdviceById($adviceId)
    {
        $apiUrl = 'https://api.adviceslip.com/advice/' . urlencode($adviceId);
    }
}

?>